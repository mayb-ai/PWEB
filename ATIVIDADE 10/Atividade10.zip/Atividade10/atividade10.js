

function IMC(Altura, Peso){
    imc = peso/Math.pow(altura, 2);

    switch(true){
        case (imc < 18.5):
            alert("Magreza - Obesidade Grau 0");
            break;
        case (imc < 25):
            alert("Normal - Obesidade Grau 0");
            break;
        case (imc < 30):
            alert("Sobrepeso - Obesidade Grau I");
            break;
        case (imc < 40):
            alert("Obesidade - Obesidade Grau II");
            break;
        case (imc > 40):
            alert("Obesidade Grave - Obesidae Grau III");
            break;
    }
}

let altura;
let peso;
let imc

altura = prompt("Digite sua altura: ");
peso = prompt("Digite seu peso: ");
IMC(altura, peso);