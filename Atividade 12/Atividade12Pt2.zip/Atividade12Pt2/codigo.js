class Conta {
    constructor(nome, banco, numConta, saldo) {
        this._nome = nome;
        this._banco = banco;
        this._numConta = numConta;
        this._saldo = saldo;
    }

    get nome() {
        return this._nome;
    }
    set nome(valor) {
        this._nome = valor;
    }

    get banco() {
        return this._banco;
    }
    set banco(valor) {
        this._banco = valor;
    }

    get numConta() {
        return this._numConta;
    }
    set numConta(valor) {
        this._numConta = valor;
    }

    get saldo() {
        return this._saldo;
    }
    set saldo(valor) {
        this._saldo = valor;
    }
}

class Corrente extends Conta {
    constructor(nome, banco, numConta, saldo, saldoEspecial) {
        super(nome, banco, numConta, saldo);
        this._saldoEspecial = saldoEspecial;
    }

    get saldoEspecial() {
        return this._saldoEspecial;
    }
    set saldoEspecial(valor) {
        this._saldoEspecial = valor;
    }
}

class Poupanca extends Conta {
    constructor(nome, banco, numConta, saldo, juros, dataVencimento) {
        super(nome, banco, numConta, saldo);
        this._juros = juros;
        this._dataVencimento = dataVencimento;
    }

    get juros() {
        return this._juros;
    }
    set juros(valor) {
        this._juros = valor;
    }

    get dataVencimento() {
        return this._dataVencimento;
    }
    set dataVencimento(valor) {
        this._dataVencimento = valor;
    }
}

// Coletando dados do usuário
const nome = prompt("Digite seu nome: ");
const banco = prompt("Digite o nome do banco: ");
const numConta = prompt("Digite o número da conta: ");
const saldo = prompt("Digite o saldo: ");
const saldoEspecial = prompt("Digite o saldo especial: ");
const juros = prompt("Digite os juros: ");
const dataVencimento = prompt("Digite a data de vencimento: ");

// Criando objetos
const objCorrente = new Corrente(nome, banco, numConta, saldo, saldoEspecial);
const objPoupanca = new Poupanca(nome, banco, numConta, saldo, juros, dataVencimento);

// Mostrando os dados
alert(
    "INFORMAÇÕES DA CONTA CORRENTE\n\n" +
    "Nome: " + objCorrente.nome +
    "\nBanco: " + objCorrente.banco +
    "\nNúmero da conta: " + objCorrente.numConta +
    "\nSaldo: R$" + objCorrente.saldo +
    "\nSaldo Especial: R$" + objCorrente.saldoEspecial +
    "\n\nINFORMAÇÕES DA CONTA POUPANÇA\n\n" +
    "Nome: " + objPoupanca.nome +
    "\nBanco: " + objPoupanca.banco +
    "\nNúmero da conta: " + objPoupanca.numConta +
    "\nSaldo: R$" + objPoupanca.saldo +
    "\nJuros: " + objPoupanca.juros + "%" +
    "\nData de Vencimento: " + objPoupanca.dataVencimento
);
