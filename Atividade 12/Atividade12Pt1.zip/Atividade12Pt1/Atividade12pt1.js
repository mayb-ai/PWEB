class Retangulo{
    constructor(){
        this.x = x; //base
        this.y = y; //altura
    }

    calcArea(){
        var area = this.x*this.y;

        alert("Área do Retângulo = " + area);
    }
}

x = prompt("Digite o valor da base do retângulo: ");
y = prompt("Digite o valor da altura do retângulo: ");
const objRetangulo = new Retangulo(x, y);

objRetangulo.calcArea();